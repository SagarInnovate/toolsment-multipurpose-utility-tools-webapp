<?php $__env->startSection('head'); ?>
    <?php
    include 'public/code_path/extracted/' . $tool->source_code_file_url . '/head.php';
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-section'); ?>
    <?php
    include 'public/code_path/extracted/' . $tool->source_code_file_url . '/main.php';
    ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel projects\toolsment v2.0\toolsment\resources\views/public/tt.blade.php ENDPATH**/ ?>