<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Under Maintenance">
    <meta name="description" content="">
    <title>under-maintenance</title>
    <link rel="stylesheet" href="{{css_path('nicepage.css','public')}}" media="screen">
<link rel="stylesheet" href="{{css_path('under-maintenance.css','public')}}" media="screen">
    <script class="u-script" type="text/javascript" src="{{js_path('jquery.js','public')}}" "="" defer=""></script>
    <script class="u-script" type="text/javascript" src="{{js_path('nicepage.js','public')}}" "="" defer=""></script>
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,
  </head>
  <body class="u-body u-xl-mode" data-lang="en">
    <section class="u-clearfix u-gradient u-section-1" id="sec-2a58">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <div class="u-align-center u-container-style u-group u-radius-31 u-shape-round u-white u-group-1" data-animation-name="customAnimationIn" data-animation-duration="1000" data-animation-direction="">
          <div class="u-container-layout u-container-layout-1">
            <div class="u-align-center u-clearfix u-expanded-width u-group-elements u-valign-middle u-group-elements-1"><span class="u-file-icon u-icon u-icon-1"><img src="{{img_path('1892446.png')}}" alt=""></span>
              <h1 class="u-custom-font u-font-ubuntu u-text u-title u-text-1">Under Maintenance</h1>
            </div>
            <p class="u-align-center u-text u-text-2"> Sorry for the inconvenience. We’re performing some maintenance at the moment.Our developers are hard at work updating your system. Please wait while we do this.</p>
            <a href="/" class="u-border-none u-btn u-btn-round u-button-style u-custom-color-2 u-hover-palette-1-light-1 u-radius-6 u-btn-1">OK</a>
          </div>
        </div>
      </div>
    </section>
    
  
</body></html>