<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="​You&amp;apos;re blocking ads">
    <meta name="description" content="">
    <title>remove_ad_blocker</title>
    <link rel="stylesheet" href="{{css_path('nicepage.css','public')}}" media="screen">
<link rel="stylesheet" href="{{css_path('remove_ad_blocker.css','public')}}" media="screen">
    <script class="u-script" type="text/javascript" src="{{js_path('jquery.js','public')}}" "="" defer=""></script>
    <script class="u-script" type="text/javascript" src="{{js_path('nicepage.js','public')}}" "="" defer=""></script>
   
  </head>
  <body class="u-body u-xl-mode" data-lang="en">
    <section class="u-clearfix u-grey-50 u-section-1" id="sec-2a67">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-container-style u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-group u-radius-31 u-shape-round u-white u-group-1" data-animation-name="customAnimationIn" data-animation-duration="1000">
          <div class="u-container-layout u-valign-middle u-container-layout-1">
            <div class="infinite u-align-center-md u-align-center-sm u-align-center-xs u-clearfix u-expanded-width u-group-elements u-valign-middle-md u-valign-middle-sm u-valign-middle-xs u-group-elements-1" data-animation-name="pulse" data-animation-duration="1000" data-animation-direction=""><span class="u-border-2 u-border-black u-file-icon u-icon u-icon-circle u-icon-1"><img src="{{img_path('1500374.png')}}" alt=""></span>
              <h1 class="u-align-center-lg u-align-center-xl u-custom-font u-font-ubuntu u-text u-title u-text-1"> You're blocking ads</h1>
            </div>
            <p class="u-align-center u-text u-text-default u-text-2"> Our website is made possible by displaying online ads to our visitors. Please consider supporting us by disabling your ad blocker.</p>
            <div class="u-align-center u-list u-list-1">
              <div class="u-repeater u-repeater-1">
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-2">
                    <a href="#" class="u-border-none u-btn u-btn-round u-button-style u-custom-color-4 u-custom-item u-hover-palette-1-light-1 u-radius-6 u-btn-1"> I have disabled Adblock</a>
                  </div>
                </div>
                <div class="u-container-style u-list-item u-repeater-item">
                  <div class="u-container-layout u-similar-container u-container-layout-3">
                    <a href="#" class="u-border-none u-btn u-btn-round u-button-style u-custom-color-2 u-custom-item u-hover-palette-1-light-1 u-radius-6 u-btn-2"> No, thanks!</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
</body></html>