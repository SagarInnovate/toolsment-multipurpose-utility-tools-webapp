<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title>user-forgot_password</title>
    <link rel="stylesheet" href="{{css_path('nicepage.css')}}" media="screen">
<link rel="stylesheet" href="{{css_path('user-forgot_password.css','user')}}" media="screen">
    <script class="u-script" type="text/javascript" src="{{js_path('jquery.js')}}" "="" defer=""></script>
    <script class="u-script" type="text/javascript" src="{{js_path('nicepage.js')}}" "="" defer=""></script>
    <meta name="generator" content="Nicepage 4.16.0, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "toolsment"
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="user-forgot_password">
    <meta property="og:description" content="">
    <meta property="og:type" content="website">
  </head>
  <body class="u-body u-xl-mode" data-lang="en">
    <section class="u-clearfix u-gradient u-section-1" id="sec-0d6f">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-align-center u-form u-form-1">
          <form action="#" method="POST" class="u-clearfix u-form-custom-backend u-form-spacing-10 u-form-vertical u-inner-form" source="custom" name="form" style="padding: 10px;" redirect="true">
            <div class="u-form-email u-form-group">
              <label for="name-5199" class="u-label u-text-body-alt-color">Email</label>
              <input type="email" placeholder="Enter Email" id="name-5199" name="email-1" class="u-border-3 u-border-grey-30 u-input u-input-rectangle u-radius-11 u-white u-input-1" required="required">
            </div>
            <div class="u-form-group u-form-group-2">
              <label for="text-78ec" class="u-label u-text-body-alt-color">Password</label>
              <input type="text" placeholder="enter new password" id="text-78ec" name="password" class="u-border-3 u-border-grey-30 u-input u-input-rectangle u-radius-11 u-white u-input-2" required="required">
            </div>
            <div class="u-form-group u-form-group-3">
              <label for="text-6649" class="u-label u-text-body-alt-color">Confirm password</label>
              <input type="text" placeholder="plz confirm your password" id="text-6649" name="confirm_pass" class="u-border-3 u-border-grey-30 u-input u-input-rectangle u-radius-11 u-white u-input-3" required="required">
            </div>
            <div class="u-align-center u-form-group u-form-submit">
              <a href="#" class="u-border-none u-btn u-btn-round u-btn-submit u-button-style u-custom-color-2 u-radius-10 u-btn-1">Submit</a>
              <input type="submit" value="submit" class="u-form-control-hidden">
            </div>
            <div class="u-form-send-message u-form-send-success"> Thank you! Your message has been sent. </div>
            <div class="u-form-send-error u-form-send-message"> Unable to send your message. Please fix errors then try again. </div>
            <input type="hidden" value="" name="recaptchaResponse">
          </form>
        </div>
      </div>
    </section>
    
    
    
  
</body></html>