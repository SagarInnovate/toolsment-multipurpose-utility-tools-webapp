@include('layouts.header')
@include('layouts.admin-nav')
@yield('main-section')
@include('layouts.footer')