<footer class="u-align-right u-clearfix u-footer u-grey-80" id="sec-7df8"><div class="u-clearfix u-sheet u-sheet-1">
    <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
      <div class="u-layout">
        <div class="u-layout-row">
          <div class="u-container-style u-layout-cell u-size-28 u-layout-cell-1">
            <div class="u-border-1 u-border-custom-color-3 u-border-no-left u-border-no-right u-border-no-top u-container-layout u-valign-top u-container-layout-1">
              <h3 class="u-align-center u-headline u-text u-text-1">
                <a href="/">
                  <span class="u-text-custom-color-2">T</span>ools<span class="u-text-custom-color-2">M</span>ent
                </a>
              </h3>
              <p class="u-align-center u-custom-font u-font-ubuntu u-text u-text-2"> Toolsment is a free web and seo tool site </p>
            </div>
          </div>
          <div class="u-align-center u-container-style u-layout-cell u-size-32 u-layout-cell-2">
            <div class="u-border-1 u-border-custom-color-3 u-border-no-left u-border-no-right u-border-no-top u-container-layout u-valign-middle-sm u-valign-middle-xs u-container-layout-2">
              <p class="u-align-center u-text u-text-3">copyright©ToolsMent 2022</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <nav class="u-align-center u-menu u-menu-dropdown u-offcanvas u-menu-1" data-responsive-from="SM">
      <div class="menu-collapse" style="font-size: 0.875rem; letter-spacing: 0px;">
        <a class="u-button-style u-custom-active-border-color u-custom-border u-custom-border-color u-custom-borders u-custom-hover-border-color u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-custom-top-bottom-menu-spacing u-nav-link" href="#" style="padding: 4px 162px; font-size: calc(1em + 8px);">
          <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-a8cc"></use></svg>
          <svg class="u-svg-content" version="1.1" id="svg-a8cc" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
        </a>
      </div>
      <div class="u-custom-menu u-nav-container">
        <ul class="u-nav u-spacing-30 u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-palette-2-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-custom-color-3 u-text-hover-palette-2-base" href="/" style="padding: 6px 0px;">home</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-palette-2-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-custom-color-3 u-text-hover-palette-2-base" href="/about" style="padding: 6px 0px;">About</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-palette-2-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-custom-color-3 u-text-hover-palette-2-base" href="tools" style="padding: 6px 0px;">Tools</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-palette-2-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-custom-color-3 u-text-hover-palette-2-base" href="/blogs" style="padding: 6px 0px;">Blogs</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-palette-2-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-custom-color-3 u-text-hover-palette-2-base" href="/contact" style="padding: 6px 0px;">Contact</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-palette-2-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-custom-color-3 u-text-hover-palette-2-base" href="/privacy-policy" style="padding: 6px 0px;">Privacy-Policy</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-palette-2-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-custom-color-3 u-text-hover-palette-2-base" href="/terms-and-conditions" style="padding: 6px 0px;">Terms-And-Conditions</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-palette-2-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-custom-color-3 u-text-hover-palette-2-base" href="/disclaimer" style="padding: 6px 0px;">Disclaimer</a>
</li></ul>
      </div>
      <div class="u-custom-menu u-nav-container-collapse">
        <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
          <div class="u-inner-container-layout u-sidenav-overflow">
            <div class="u-menu-close"></div>
            <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/about">About</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/tools">Tools</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/blogs">Blogs</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/contact">Contact</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/privacy-policy">Privacy-Policy</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/terms-and-conditions">Terms-And-Conditions</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/disclaimer">Disclaimer</a>
</li></ul>
          </div>
        </div>
        <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
      </div>
    </nav>
  </div></footer>
      <script class="u-script" type="text/javascript" src="{{ js_path('jquery.js') }}" "="" defer=""></script>
      <script class=" u-script" type="text/javascript" src="{{ js_path('nicepage.js') }}" "="" defer=""></script>

</body></html>
