<!DOCTYPE html>
<html style="font-size: 16px;" lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords"
    content="ToolsMent, ​Free Online Web Tools​, ​Website Tracking Tools​, ​List of free tools in one place to measure, monitor, and track your website performance,free web tool,smart web tools, h super tools, h-supertools,tool website,online web tool,free online web tool,best online web tool,website layout design tool free,web devlopment tool,web designing tools for begineers,free web tool for website,free web tools for designers,free web tool for teachers,free web tool for students,best free web tools,best free website anyalytics tool,free web analytics tools,web traffic analysis tools free,free tools for website analysis,free tools for text analysis,best free web analytics ,what are the web analytics tools,tools for website analysis,what are web analytics tools,free crypto analysis tools,free web measure tool tools download,free web measure tool tools for pc,free web measure tool tools for testing,free web measure tool tools for windows 10,free web measure tool tools download for pc,video converter,video converter free download,any video converter,online converter,file converter download,freemake video converter,st to pst free converter tool,best free converter tool,passive voice to active voice converter tool online free,active to passive converter tool online free,free pdf to excel converter tool,sql to linq converter online tool free,,ost to pst converter tool free download,vce to pdf converter online tool free,free cc converter tool,free pdf converter tool,free ost to pst converter tool,free video converter tool,free manglish to malayalam converter tool,free ssl converter tool,free exe to msi converter tool,free download exe to apk converter tool for pc,free email converter tool,video converter,video converter free download,any video converter,online converter,file converter download,freemake video converter,
free seo checker,best free seo tools,free seo tools for youtube,ahrefs,free seo tools for keyword research,google seo tools free,seo tools,top 5 free seo tools,free seo checker,,seo tools,best free seo tools,ahrefs,small seo tools,free seo tools for youtube,free seo tools for website,free seo tools 2021,free seo tools 2020,free seo tools plagiarism checker,free seo tools for competitor analysis,free seo tool for website analysis,free seo tool for wordpress,free seo tool online,free seo tools for youtube videos,best free seo tool,neil patel free seo tool,free seo tools,free seo tools for keyword research,free seo tools for youtube,free seo tools for blogger,free seo tools for wordpress,free seo tools online,free youtube seo tool,free keyword seo tool,free etsy seo tool,
">
    <link rel="stylesheet" href="{{ css_path('nicepage.css') }}" media="screen">
    @yield('head')
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Titillium+Web:200,200i,300,300i,400,400i,600,600i,700,700i,900|Lobster:400|PT+Sans:400,400i,700,700i|Ubuntu:300,300i,400,400i,500,500i,700,700i">
</head>
<body class="u-body u-xl-mode" data-lang="en"><header class="u-align-center-sm u-align-center-xs u-box-shadow u-clearfix u-header u-sticky u-sticky-a5e1 u-white u-header" id="sec-2b73"><div class="u-clearfix u-sheet u-sheet-1">
    <a class="u-active-none u-align-left u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-body-color u-btn-1" href="/"> &nbsp;<span class="u-text-custom-color-2">T</span>ools<span class="u-text-custom-color-2">M</span>ent
    </a>
    <nav class="u-menu u-menu-one-level u-offcanvas u-menu-1">
      <div class="menu-collapse u-custom-font u-font-pt-sans" style="font-size: 1rem; letter-spacing: 0px;">
        <a class="u-button-style u-custom-active-border-color u-custom-border u-custom-border-color u-custom-borders u-custom-hover-border-color u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-custom-top-bottom-menu-spacing u-nav-link" href="#" style="padding: 2px 0px; font-size: calc(1em + 4px);">
          <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-f8b2"></use></svg>
          <svg class="u-svg-content" version="1.1" id="svg-f8b2" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
        </a>
      </div>
      <div class="u-custom-menu u-nav-container">
        <ul class="u-custom-font u-font-pt-sans u-nav u-spacing-30 u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-custom-color-2 u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-grey-90 u-text-hover-grey-90" href="/" style="padding: 10px 0px;">Home</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-custom-color-2 u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-grey-90 u-text-hover-grey-90" href="/tools" style="padding: 10px 0px;">Tools</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-custom-color-2 u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-grey-90 u-text-hover-grey-90" href="/blogs" style="padding: 10px 0px;">Blogs</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-custom-color-2 u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-grey-90 u-text-hover-grey-90" href="/about" style="padding: 10px 0px;">About</a>
</li><li class="u-nav-item"><a class="u-border-2 u-border-active-custom-color-2 u-border-hover-custom-color-2 u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-custom-color-2 u-text-grey-90 u-text-hover-grey-90" href="/contact" style="padding: 10px 0px;">Contact</a>
</li></ul>
      </div>
      <div class="u-custom-menu u-nav-container-collapse">
        <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
          <div class="u-inner-container-layout u-sidenav-overflow">
            <div class="u-menu-close"></div>
            <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/tools">Tools</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/blogs">Blogs</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/about">About</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="/contact">Contact</a>
</li></ul>
          </div>
        </div>
        <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
      </div>
    </nav>
  </div><style class="u-sticky-style" data-style-id="a5e1">.u-sticky-fixed.u-sticky-a5e1:before, .u-body.u-sticky-fixed .u-sticky-a5e1:before {
borders: top right bottom left !important
}</style></header>
